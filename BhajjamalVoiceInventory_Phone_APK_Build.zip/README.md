# Bhajjamal & Sons Inventory — Version 1.0 starter

Native Android Studio project.

Included:
- Voice inventory command input with English-India speech recognition
- Common Hindi/Hinglish inventory words normalization
- Confirmation before stock changes
- Persistent local product inventory
- Add product with size, opening stock, unit, minimum stock, batch and expiry
- Search
- Stock +/- controls
- Low-stock highlighting
- Inventory summary

Production roadmap already prepared:
- Import 200+ products from CSV/Excel
- Cloud database and backup
- Staff accounts + audit trail
- Proper Hindi/Hinglish natural-language parser
- Batch/expiry alerts
- Purchase/supplier module
- Reports/export
- APK signing/release configuration

This is source code/build starter; an Android build environment is required to produce the installable APK.
