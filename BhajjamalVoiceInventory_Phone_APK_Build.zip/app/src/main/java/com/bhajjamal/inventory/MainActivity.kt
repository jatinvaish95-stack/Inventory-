package com.bhajjamal.inventory

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class Product(var name:String,var size:String,var qty:Int,var unit:String,var min:Int,var batch:String="",var expiry:String="")

class MainActivity:Activity(){
 private val ps=mutableListOf<Product>()
 private val hist=mutableListOf<String>()
 private val pref by lazy{getSharedPreferences("bvi",0)}
 private lateinit var list:LinearLayout; private lateinit var status:TextView; private lateinit var search:EditText

 override fun onCreate(b:Bundle?){super.onCreate(b);load();if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),9);ui()}

 private fun load(){
  val s=pref.getString("products",null)
  if(s==null){ps.addAll(listOf(
   Product("Sugar Balance Juice","500 ml",47,"bottles",10),
   Product("Neem Karela Jamun Juice","500 ml",32,"bottles",10),
   Product("Punarnava Makoy Kutki Juice","500 ml",8,"bottles",10),
   Product("Sugar Amrit Churna","100 gm",64,"packs",10),
   Product("Mahashakti Oil","100 ml",22,"bottles",8)
  ));save()} else {val a=JSONArray(s);for(i in 0 until a.length()){val o=a.getJSONObject(i);ps.add(Product(o.getString("name"),o.getString("size"),o.getInt("qty"),o.getString("unit"),o.getInt("min"),o.optString("batch"),o.optString("expiry")))}}
 }
 private fun save(){val a=JSONArray();ps.forEach{p->a.put(JSONObject().apply{put("name",p.name);put("size",p.size);put("qty",p.qty);put("unit",p.unit);put("min",p.min);put("batch",p.batch);put("expiry",p.expiry)})};pref.edit().putString("products",a.toString()).apply()}

 private fun ui(){
  val scroll=ScrollView(this);val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18)}
  val brand=TextView(this).apply{text="BHAJJAMAL & SONS";textSize=13f};val title=TextView(this).apply{text="VOICE INVENTORY";textSize=27f;setPadding(0,4,0,16)}
  val mic=Button(this).apply{text="🎙️  SPEAK INVENTORY COMMAND";setOnClickListener{voice()}}
  status=TextView(this).apply{text="Ready";textSize=16f;setPadding(0,10,0,4)}
  val help=TextView(this).apply{text="Example: “Sugar Balance Juice 500 ml 20 received”\n“Neem Karela Jamun Juice 500 ml 5 sold”";setPadding(0,0,0,14)}
  search=EditText(this).apply{hint="Search product";setPadding(10,10,10,10)}
  val add=Button(this).apply{text="＋ Add Product";setOnClickListener{addDialog()}}
  val report=Button(this).apply{text="📊 Inventory Summary";setOnClickListener{summary()}}
  list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){render()};override fun afterTextChanged(e:android.text.Editable?) {}})
  root.addView(brand);root.addView(title);root.addView(mic);root.addView(status);root.addView(help);root.addView(search);root.addView(add);root.addView(report);root.addView(list)
  scroll.addView(root);setContentView(scroll);render()
 }

 private fun norm(s:String)=s.lowercase(Locale.getDefault()).replace("बोतल","bottles").replace("बॉटल","bottles").replace("पीस","pieces").replace("आए","received").replace("आया","received").replace("मिला","received").replace("बेचा","sold").replace("बिका","sold").replace("निकाला","removed").replace("जोड़ो","add").replace("घटाओ","remove")

 private fun voice(){
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN");putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak inventory command")}
  try{startActivityForResult(i,100);status.text="Listening..."}catch(e:Exception){status.text="Voice recognition unavailable"}
 }

 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r!=100||c!=RESULT_OK)return
  val raw=d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:return;val t=norm(raw);status.text="Heard: $raw"
  val p=ps.maxByOrNull{norm(it.name+" "+it.size).split(" ").count{w->w.length>2&&t.contains(w)}};val n=Regex("(\\d+)").find(t)?.groupValues?.get(1)?.toIntOrNull()
  if(p==null||n==null||p.name=="") {status.text="Could not understand product/quantity";return}
  val remove=Regex("sold|sale|remove|removed|out|बेच|बिक|निकाल",RegexOption.IGNORE_CASE).containsMatchIn(t);val delta=if(remove)-n else n
  AlertDialog.Builder(this).setTitle("Confirm stock change").setMessage("${p.name} ${p.size}\n${if(delta>0)"ADD" else "REMOVE"} ${kotlin.math.abs(delta)} ${p.unit}?").setNegativeButton("Cancel",null).setPositiveButton("Confirm"){_,_->p.qty=(p.qty+delta).coerceAtLeast(0);hist.add("${p.name}: ${if(delta>0)"+$delta" else "$delta"} ${p.unit}");save();render();status.text="Stock updated successfully"}.show()
 }

 private fun render(){list.removeAllViews();val q=search.text.toString();ps.filter{("${it.name} ${it.size}").contains(q,true)}.forEach{p->
  val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,12,0,12)}
  val t=TextView(this).apply{text="${p.name} ${p.size}   —   ${p.qty} ${p.unit}";textSize=16f;if(p.qty<=p.min)setTextColor(0xff9a4b00.toInt())}
  val meta=TextView(this).apply{text="Min: ${p.min}${if(p.batch.isNotBlank())"  • Batch: ${p.batch}" else ""}${if(p.expiry.isNotBlank())"  • Exp: ${p.expiry}" else ""}";textSize=12f}
  val b=LinearLayout(this);b.addView(Button(this).apply{text="−";setOnClickListener{p.qty=(p.qty-1).coerceAtLeast(0);save();render()}});b.addView(Button(this).apply{text="+";setOnClickListener{p.qty++;save();render()}})
  row.addView(t);row.addView(meta);row.addView(b);list.addView(row)
 }}

 private fun addDialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
  val n=EditText(this).apply{hint="Product name"};val s=EditText(this).apply{hint="Size (500 ml / 100 gm)"}
  val q=EditText(this).apply{hint="Opening stock";inputType=2};val u=EditText(this).apply{hint="Unit (bottles/packs)"}
  val m=EditText(this).apply{hint="Minimum stock";inputType=2};val b=EditText(this).apply{hint="Batch (optional)"};val e=EditText(this).apply{hint="Expiry (optional)"}
  listOf(n,s,q,u,m,b,e).forEach{box.addView(it)}
  AlertDialog.Builder(this).setTitle("Add Product").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->if(n.text.isNotBlank()){ps.add(Product(n.text.toString(),s.text.toString(),q.text.toString().toIntOrNull()?:0,u.text.toString().ifBlank{"units"},m.text.toString().toIntOrNull()?:5,b.text.toString(),e.text.toString()));save();render()}}.show()
 }

 private fun summary(){val total=ps.sumOf{it.qty};val low=ps.count{it.qty<=it.min};AlertDialog.Builder(this).setTitle("Inventory Summary").setMessage("Products: ${ps.size}\nTotal units: $total\nLow stock items: $low").setPositiveButton("OK",null).show()}
}