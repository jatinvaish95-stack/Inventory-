# Phone-only APK build

1. Create a GitHub repository.
2. Upload the contents of this project to the repository (not the outer ZIP folder).
3. Open the repository's **Actions** tab.
4. Select **Build APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the artifact named:
   `Bhajjamal-Voice-Inventory-APK`
8. Extract the artifact and install `app-debug.apk` on the Android phone.

The workflow builds a debug APK; it does not require a laptop.
